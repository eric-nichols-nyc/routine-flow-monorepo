(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0cbb5c1b._.js",
  "static/chunks/fc183_next_dist_compiled_react-dom_a207e7be._.js",
  "static/chunks/fc183_next_dist_compiled_react-server-dom-turbopack_e6944af5._.js",
  "static/chunks/fc183_next_dist_compiled_next-devtools_index_fe854f08.js",
  "static/chunks/fc183_next_dist_compiled_9552ba4a._.js",
  "static/chunks/fc183_next_dist_client_d060f8cc._.js",
  "static/chunks/fc183_next_dist_2e2bdd56._.js",
  "static/chunks/0d74b_@swc_helpers_cjs_056b4024._.js"
],
    source: "entry"
});
