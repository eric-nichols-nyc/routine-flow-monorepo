(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Documents_routine-flow-monorepo_22091366._.css",
  "static/chunks/149fc_next-themes_dist_index_mjs_67a6a895._.js"
],
    source: "dynamic"
});
