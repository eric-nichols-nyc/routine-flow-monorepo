(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1116d__pnpm_047caf25._.js",
  "static/chunks/Documents_routine-flow-monorepo_bc4bd854._.js"
],
    source: "dynamic"
});
